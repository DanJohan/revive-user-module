<?php

define('MAIL_HOST',getenv('MAIL_HOST'));
define('MAIL_USERNAME',getenv('MAIL_USERNAME'));
define('MAIL_PASSWORD',getenv('MAIL_PASSWORD'));
define('MAIL_PORT',getenv('MAIL_PORT'));


define('FB_APP_ID', getenv('FB_APP_ID'));
define('FB_SECRET_KEY',getenv('FB_SECRET_KEY'));
define('FB_VERSION',getenv('FB_VERSION'));

define('GMAIL_CLIENT_ID',getenv('GMAIL_CLIENT_ID'));
define('GMAIL_CLIENT_SECRET',getenv('GMAIL_CLIENT_SECRET'));
define('GMAIL_API_KEY',getenv('GMAIL_API_KEY'));?>